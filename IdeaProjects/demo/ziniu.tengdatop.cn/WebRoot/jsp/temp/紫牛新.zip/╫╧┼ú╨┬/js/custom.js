jQuery(document).ready(function() {

   "use strict";

   // Tooltip
   jQuery('.tooltips').tooltip({ container: 'body'});

   // Popover
   jQuery('.popovers').popover();

   // Show panel buttons when hovering panel heading
   // jQuery('.panel-heading').hover(function() {
   //    jQuery(this).find('.panel-btns').fadeIn('fast');
   // }, function() {
   //    jQuery(this).find('.panel-btns').fadeOut('fast');
   // });

   // Close Panel
   jQuery('.panel .panel-close').click(function() {
      jQuery(this).closest('.panel').fadeOut(200);
      return false;
   });

   // Minimize Panel
   jQuery('.panel .panel-minimize').click(function(){
      var t = jQuery(this);
      var p = t.closest('.panel');
      if(!jQuery(this).hasClass('maximize')) {
         p.find('.panel-body, .panel-footer').slideUp(200);
         t.addClass('maximize');
         // t.find('i').removeClass('fa-minus').addClass('fa-plus');
         t.find('i').text('展开');
         jQuery(this).attr('data-original-title','Maximize Panel').tooltip();
      } else {
         p.find('.panel-body, .panel-footer').slideDown(200);
         t.removeClass('maximize');
         // t.find('i').removeClass('fa-plus').addClass('fa-minus');
         t.find('i').text('收起');
         jQuery(this).attr('data-original-title','Minimize Panel').tooltip();
      }
      return false;
   });

   jQuery('.leftpanel .nav .parent > a').click(function() {

      var coll = jQuery(this).parents('.collapsed').length;

      if (!coll) {
         jQuery('.leftpanel .nav .parent-focus').each(function() {
            jQuery(this).find('.children').slideUp('fast');
            jQuery(this).removeClass('parent-focus');
         });

         var child = jQuery(this).parent().find('.children');
         if(!child.is(':visible')) {
            child.slideDown('fast');
            if(!child.parent().hasClass('active'))
               child.parent().addClass('parent-focus');
         } else {
            child.slideUp('fast');
            child.parent().removeClass('parent-focus');
         }
      }
      return false;
   });


   // Menu Toggle
   jQuery('.menu-collapse').click(function() {
      if (!$('body').hasClass('hidden-left')) {
         if ($('.headerwrapper').hasClass('collapsed')) {
            $('.headerwrapper, .mainwrapper').removeClass('collapsed');
         } else {
            $('.headerwrapper, .mainwrapper').addClass('collapsed');
            $('.children').hide(); // hide sub-menu if leave open
         }
      } else {
         if (!$('body').hasClass('show-left')) {
            $('body').addClass('show-left');
         } else {
            $('body').removeClass('show-left');
         }
      }
      return false;
   });

   // Add class nav-hover to mene. Useful for viewing sub-menu
   jQuery('.leftpanel .nav li').hover(function(){
      $(this).addClass('nav-hover');
   }, function(){
      $(this).removeClass('nav-hover');
   });

   // For Media Queries
   jQuery(window).resize(function() {
      hideMenu();
   });

   hideMenu(); // for loading/refreshing the page
   function hideMenu() {

      if($('.header-right').css('position') == 'relative') {
         $('body').addClass('hidden-left');
         $('.headerwrapper, .mainwrapper').removeClass('collapsed');
      } else {
         $('body').removeClass('hidden-left');
      }
	  
	  // Seach form move to left
      if ($(window).width() <= 480) {
         if ($('.leftpanel .form-search').length == 0) {
            $('.form-search').insertAfter($('.profile-left'));
         }
      } else {
         if ($('.header-right .form-search').length == 0) {
            $('.form-search').insertBefore($('.btn-group-notification'));
         }
      }
   }
   
   collapsedMenu(); // for loading/refreshing the page
   function collapsedMenu() {
      if($('.logo').css('position') == 'relative') {
         $('.headerwrapper, .mainwrapper').addClass('collapsed');
      } else {
         $('.headerwrapper, .mainwrapper').removeClass('collapsed');
      }
   }
   	/*==Slim Scroll ==*/
	if ($.fn.slimScroll) {
		$('.widget-todo ul').slimscroll({
			height: '300px',
			wheelStep: 35
		});
	}
});


jQuery(function($){ 
            $.datepicker.regional['zh-CN'] = {
                clearText: '清除', 
                clearStatus: '清除已选日期', 
                closeText: '关闭', 
                closeStatus: '不改变当前选择', 
                prevText: '< 上月', 
                prevStatus: '显示上月', 
                prevBigText: '<<', 
                prevBigStatus: '显示上一年', 
                nextText: '下月>', 
                nextStatus: '显示下月', 
                nextBigText: '>>', 
                nextBigStatus: '显示下一年', 
                currentText: '今天', 
                currentStatus: '显示本月', 
                monthNames: ['一月','二月','三月','四月','五月','六月', '七月','八月','九月','十月','十一月','十二月'], 
                monthNamesShort: ['一月','二月','三月','四月','五月','六月', '七月','八月','九月','十月','十一月','十二月'], 
                monthStatus: '选择月份', 
                yearStatus: '选择年份', 
                weekHeader: '周', 
                weekStatus: '年内周次', 
                dayNames: ['星期日','星期一','星期二','星期三','星期四','星期五','星期六'], 
                dayNamesShort: ['周日','周一','周二','周三','周四','周五','周六'], 
                dayNamesMin: ['日','一','二','三','四','五','六'], 
                dayStatus: '设置 DD 为一周起始', 
                dateStatus: '选择 m月 d日, DD', 
                dateFormat: 'yy-mm-dd', 
                firstDay: 1, 
                initStatus: '请选择日期', 
                isRTL: false
            }; 
            $.datepicker.setDefaults($.datepicker.regional['zh-CN']); 
        });