package demo;
import java.io.File;
import java.util.List;
import java.util.Map;
import com.mc.core.entity.auto.Field;
import com.mc.core.entity.auto.Table;
import com.mc.core.template.EntityTemplate;
import com.mc.core.template.TemplateConfig;
import com.mc.core.template.impl.TacitEntityTemplateImpl;
public class MyCustomEntityTemplate extends TacitEntityTemplateImpl implements EntityTemplate {
	public List<String> getImportClass(TemplateConfig config, List<Field> fields) {
		return super.getImportClass(config, fields);
	}
	public List<String> getClassNote(Table table) {
		return super.getClassNote(table);
	}
	public List<String> getFieldDeclaration(TemplateConfig config, List<Field> fields) {
		return super.getFieldDeclaration(config, fields);
	}
	public List<String> getClassConstructor(TemplateConfig config, Table table, Field primary) {
		return super.getClassConstructor(config, table, primary);
	}
	public List<String> getClassConstructor(TemplateConfig config, Table table, List<Field> primarys) {
		return super.getClassConstructor(config, table, primarys);
	}
	public List<String> getMethodDeclaration(TemplateConfig config, Table table, List<Field> fields, Map<Integer, String> bounds) {
		return super.getMethodDeclaration(config, table, fields, bounds);
	}
	public String toString(TemplateConfig config, Table table, List<Field> fields, List<Field> primarys, Map<Integer, String> bounds) {
		return super.toString(config, table, fields, primarys, bounds);
	}
	public File toString(TemplateConfig config, Table table, List<Field> fields, List<Field> primarys, Map<Integer, String> bounds, String target) throws Exception {
		return super.toString(config, table, fields, primarys, bounds, target);
	}
}