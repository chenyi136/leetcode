package demo;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.client.RestTemplate;
import com.mc.core.entity.auto.Field;
import com.mc.core.entity.auto.Table;
import com.mc.core.template.DaoImplTemplate;
import com.mc.core.template.DaoMapperTemplate;
import com.mc.core.template.DaoTemplate;
import com.mc.core.template.EntityTemplate;
import com.mc.core.template.ServiceImplTemplate;
import com.mc.core.template.ServiceTemplate;
import com.mc.core.template.TemplateConfig;
import com.mc.core.template.impl.PortalDaoImplTemplateImpl;
import com.mc.core.template.impl.PortalDaoMapperTemplateImpl;
import com.mc.core.template.impl.PortalDaoTemplateImpl;
import com.mc.core.template.impl.PortalEntityTemplateImpl;
import com.mc.core.template.impl.PortalServiceImplTemplateImpl;
import com.mc.core.template.impl.PortalServiceTemplateImpl;
import com.mc.core.template.impl.TacitDaoImplTemplateImpl;
import com.mc.core.template.impl.TacitDaoMapperTemplateImpl;
import com.mc.core.template.impl.TacitDaoTemplateImpl;
import com.mc.core.template.impl.TacitEntityTemplateImpl;
import com.mc.core.template.impl.TacitServiceImplTemplateImpl;
import com.mc.core.template.impl.TacitServiceTemplateImpl;
/**
 * 使用项目构建生成本地代码<br>
 * 平台访问地址：<a href="http://portal.ink10000.com/">http://portal.ink10000.com/</a><br>
 * 平台游客账号：demo<br>
 * 平台登录密码：123456<br>
 * */
public class 执行入口 {
	/**
	 * 打开<a href="http://portal.ink10000.com/auto/work/list.htm">我的空间</a>后点击【编辑】按钮查看【签名票据】
	 * */
	public static final String TOKEN = "1.1WTe7wqAoI5IAfcp1tokV/ommLuEWBmrZJJkYNW6kN4Rfb9Fsrqez+Dje7nZFKoMP2HsJ0XMdg5FtHEnKfiGsQ==";
	/**
	 * 打开<a href="http://portal.ink10000.com/auto/table/list.htm">对象管理</a>后点击【另存为】按钮导出【对象信息】（复选主键）
	 * */
	public static final Integer[] TABLES = new Integer[] { 1 };
	/**
	 * 打开<a href="http://portal.ink10000.com/auto/project/list.htm">工作项目</a>后点击【另存为】按钮导出【项目信息】（复选主键）
	 * */
	public static final Integer PROJECT = 10;
	
	private static EntityTemplate entityTemplate;
	private static DaoTemplate daoTemplate;
	private static DaoImplTemplate daoImplTemplate;
	private static DaoMapperTemplate daoMapperTemplate;
	private static ServiceTemplate serviceTemplate;
	private static ServiceImplTemplate serviceImplTemplate;
	private static String 代码生成的目录 = "E:/demo/";
	public static void main(String[] args) throws Exception {
		//请求地址
		StringBuffer address = new StringBuffer("http://portal.zhongqilin.cn/global/template.htm");
		address.append("?KEY_JUMP_TOKEN=" + TOKEN);
		if (TABLES != null && TABLES.length > 0) {
			for (Integer id : TABLES) {
				if (id != null && id > 0) {
					address.append("&KEY_JUMP_TABLES=" + id);
				}
			}
		}
		if (PROJECT != null && PROJECT > 0) {
			address.append("&KEY_JUMP_PROJECT=" + PROJECT);
		}
		
		//报413错误说明签名票据错误 或者 参数KEY_JUMP_TABLES、KEY_JUMP_PROJECT 非法
		TemplateConfig.Data data = new RestTemplate().getForObject(address.toString(), TemplateConfig.Data.class);
		//使用默认配置
		//TemplateConfig config = new TemplateConfig();
		//使用自己的配置
		//TemplateConfig config = new TemplateConfig(data.CONFIG);
		//使用自己的配置与数据类型，打开<a href="http://portal.ink10000.com/auto/work/list.htm">我的空间</a>后点击【配置】按钮查看【模板配置】
		TemplateConfig config = new TemplateConfig(data.CONFIG, data.GENRE);
		init(2);
		
		Map<Integer, String> title = new HashMap<Integer, String>();
		for (Table table : data.TABLE) {
			title.put(table.getId(), table.getName());
		}
		for (Table table : data.TABLE) {
			List<Field> fields = data.FIELD.get(table.getId());
			List<Field> primarys = new ArrayList<Field>();
			for (Field field : fields) {
				if (config.getTypeMap().get(field.getType()) == null) {
					continue;
				}
				if (field.getMajor()) {
					primarys.add(field);
				}
			}
			if (primarys.size() < 1) {
				throw new Exception("缺少主键信息，打开http://portal.ink10000.com/auto/table/list.htm后选择相应的对象并点击【属性】按钮进入【属性信息】页面，在该页面点击【主键】按钮进行【主键修复】");
			}
			
			config.build(data.MODULE.get(table.getFkModule()), table.getClazz());
			if (代码生成的目录 != null) {
				entityTemplate.toString(config, table, fields, primarys, config.getBound(title, data.BOUND.get(table.getId())), 代码生成的目录);
				daoTemplate.toString(config, table, primarys, 代码生成的目录);
				daoImplTemplate.toString(config, table, primarys, 代码生成的目录);
				daoMapperTemplate.toString(config, table, fields, primarys, 代码生成的目录);
				serviceTemplate.toString(config, table, primarys, 代码生成的目录);
				serviceImplTemplate.toString(config, table, fields, primarys, 代码生成的目录);
			} else {
				System.out.println(entityTemplate.toString(config, table, fields, primarys, config.getBound(title, data.BOUND.get(table.getId()))));
				System.out.println("\n\n\n");
				System.out.println(daoTemplate.toString(config, table, primarys));
				System.out.println("\n\n\n");
				System.out.println(daoImplTemplate.toString(config, table, primarys));
				System.out.println("\n\n\n");
				System.out.println(daoMapperTemplate.toString(config, table, fields, primarys));
				System.out.println("\n\n\n");
				System.out.println(serviceTemplate.toString(config, table, primarys));
				System.out.println("\n\n\n");
				System.out.println(serviceImplTemplate.toString(config, table, fields, primarys));
			}
		}
	}
	private static void init(int grade) {
		entityTemplate = new TacitEntityTemplateImpl();
		daoTemplate = new TacitDaoTemplateImpl();
		daoImplTemplate = new TacitDaoImplTemplateImpl();
		daoMapperTemplate = new TacitDaoMapperTemplateImpl();
		serviceTemplate = new TacitServiceTemplateImpl();
		serviceImplTemplate = new TacitServiceImplTemplateImpl();
		if (grade == 1){
			entityTemplate = new PortalEntityTemplateImpl();
			daoTemplate = new PortalDaoTemplateImpl();
			daoImplTemplate = new PortalDaoImplTemplateImpl();
			daoMapperTemplate = new PortalDaoMapperTemplateImpl();
			serviceTemplate = new PortalServiceTemplateImpl();
			serviceImplTemplate = new PortalServiceImplTemplateImpl();
		} else if (grade == 2){
			//TODO 可以根据自己的需求实现这些接口
			entityTemplate = new MyCustomEntityTemplate();
		}
	}
}